%  Sine Cosine Algorithm (SCA)

clc
clear all
close all
warning off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic

global p1 p2 p3 p4 p5 p6 p7 p8 p9 k1 k2 k3 k4 k_smes t_smes

SearchAgents_no=20; % Number of search agents

Function_name='F2'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)

Max_iteration=50; % Maximum numbef of iterations

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);

[Best_score,Best_pos,cg_curve]=SCA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
toc

display(['The best solution obtained by SCA is : ', num2str(Best_pos)]);
display(['The best optimal value of the objective funciton found by SCA is : ', num2str(Best_score)]);

Answer_pos(:,1)=Best_pos;
Answer_cost(:,1)=Best_score;

%% braye moghyese
p1=Best_pos(1);
p2=Best_pos(2);
p3=Best_pos(3);
p4=Best_pos(4);
p5=Best_pos(5);
p6=Best_pos(6);
p7=Best_pos(7);
p8=Best_pos(8);
p9=Best_pos(9);
k1=Best_pos(10);
k2=Best_pos(11);
k3=Best_pos(12);
k4=Best_pos(13);
k_smes=Best_pos(14);
t_smes=Best_pos(15);

sim('AGC_PID_two_area_smes');
figure(1)
plot(time,delta_f1,'r','LineWidth',1.85)
xlabel('time (sec)')
ylabel('\Deltaf_1 (Hz)')
% hold on
figure(2)
plot(time,delta_f2,'r','LineWidth',1.85)
ylabel('\Deltaf_2 (Hz)')
xlabel('time (sec)')
% hold on
figure(3)
plot(time,delta_ptie,'r','LineWidth',1.85)
ylabel('\DeltaP_t_i_e (pu)')
xlabel('time (sec)')

