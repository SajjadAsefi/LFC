% This function containts full information and implementations of the benchmark 
% functions in Table 1, Table 2, and other test functins from the literature 

% lb is the lower bound: lb=[lb_1,lb_2,...,lb_d]
% up is the uppper bound: ub=[ub_1,ub_2,...,ub_d]
% dim is the number of variables (dimension of the problem)

function [lb,ub,dim,fobj] = Get_Functions_details(F)

switch F
    case 'F1'
        fobj = @F1;
        lb=-100;
        ub=100;
        dim=10;
            
    case 'F2'
        fobj=@F2;
        lb=0.01;
        ub=10;
        dim=15;
end

end

% F1

function o = F1(x)
o=sum(x.^2);
end

function o = F2(x)
global p1 p2 p3 p4 p5 p6 p7 p8 p9 k1 k2 k3 k4 k_smes t_smes

 format long;
 p1=x(1);
 p2=x(2);
 p3=x(3);
 p4=x(4);
 p5=x(5); 
 p6=x(6);
 p7=x(7);
 p8=x(8);
 p9=x(9);
 k1=x(10);
k2=x(11);
k3=x(12);
k4=x(13);
k_smes=x(14);
t_smes=x(15);
 
sim('AGC_PID_two_area_smes');
ZZ=abs(delta_f1)+abs(delta_f2)+abs(delta_ptie);
           
o=trapz(time,time.*ZZ);
end