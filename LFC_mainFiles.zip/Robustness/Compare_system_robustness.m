clc
clear all
close all

p1=9.857574858;
p2=10;
p3=5.468185916;
p4=0.03327705;
p5=0.01;
p6=0.063862067;
p7=10;
p8=8.342895432;
p9=0.055305326;
k1=0.017897251;
k2=9.050119989;
k3=0.026149802;
k4=0.015242977;
k_smes=10;
t_smes=0.030241952;
%% Deviation in B
sim('AGC_PID_controller_1.slx')
figure(1)
plot(time,delta_f1,':','LineWidth',1.85)
hold on
figure(2)
plot(time,delta_f2,':','LineWidth',1.85)
hold on
figure(3)
plot(time,delta_ptie,':','LineWidth',1.85)
hold on
sim('AGC_PID_controller_2.slx')
figure(1)
plot(time,delta_f1,'r--','LineWidth',1.85)
hold on
figure(2)
plot(time,delta_f2,'r--','LineWidth',1.85)
hold on
figure(3)
plot(time,delta_ptie,'r--','LineWidth',1.85)
hold on
sim('AGC_PID_controller_3.slx')
figure(1)
plot(time,delta_f1,'g','LineWidth',1.85)
hold on
figure(2)
plot(time,delta_f2,'g','LineWidth',1.85)
hold on
figure(3)
plot(time,delta_ptie,'g','LineWidth',1.85)
hold on
sim('AGC_PID_controller_4.slx')
figure(1)
plot(time,delta_f1,'k-.','LineWidth',1.85)
hold on
figure(2)
plot(time,delta_f2,'k-.','LineWidth',1.85)
hold on
figure(3)
plot(time,delta_ptie,'k-.','LineWidth',1.85)
hold on
sim('AGC_PID_controller_5.slx')
figure(1)
plot(time,delta_f1,'y','LineWidth',1.85)
legend('zero','+%25','-%25','+%50','-%50','Location','South')
xlabel('time (sec)')
ylabel('\Deltaf_1 (Hz)')
title('Change in frequency bias parameter (B)')
figure(2)
plot(time,delta_f2,'y','LineWidth',1.85)
legend('zero','+%25','-%25','+%50','-%50','Location','South')
xlabel('time (sec)')
ylabel('\Deltaf_2 (Hz)')
title('Change in frequency bias parameter (B)')
figure(3)
plot(time,delta_ptie,'y','LineWidth',1.85)
legend('zero','+%25','-%25','+%50','-%50','Location','South')
xlabel('time (sec)')
ylabel('\DeltaP_t_i_e (pu)')
title('Change in frequency bias parameter (B)')
%% deviation in R
sim('AGC_PID_controller_1.slx')
figure(4)
plot(time,delta_f1,':','LineWidth',1.85)
hold on
figure(5)
plot(time,delta_f2,':','LineWidth',1.85)
hold on
figure(6)
plot(time,delta_ptie,':','LineWidth',1.85)
hold on
sim('AGC_PID_controller_6.slx')
figure(4)
plot(time,delta_f1,'r--','LineWidth',1.85)
hold on
figure(5)
plot(time,delta_f2,'r--','LineWidth',1.85)
hold on
figure(6)
plot(time,delta_ptie,'r--','LineWidth',1.85)
hold on
sim('AGC_PID_controller_7.slx')
figure(4)
plot(time,delta_f1,'g','LineWidth',1.85)
hold on
figure(5)
plot(time,delta_f2,'g','LineWidth',1.85)
hold on
figure(6)
plot(time,delta_ptie,'g','LineWidth',1.85)
hold on
sim('AGC_PID_controller_8.slx')
figure(4)
plot(time,delta_f1,'k-.','LineWidth',1.85)
hold on
figure(5)
plot(time,delta_f2,'k-.','LineWidth',1.85)
hold on
figure(6)
plot(time,delta_ptie,'k-.','LineWidth',1.85)
hold on
sim('AGC_PID_controller_9.slx')
figure(4)
plot(time,delta_f1,'y','LineWidth',1.85)
legend('zero','+%25','-%25','+%50','-%50','Location','South')
xlabel('time (sec)')
ylabel('\Deltaf_1 (Hz)')
title('Change in governor speed regulation parameter (R)')
figure(5)
plot(time,delta_f2,'y','LineWidth',1.85)
legend('zero','+%25','-%25','+%50','-%50','Location','South')
xlabel('time (sec)')
ylabel('\Deltaf_2 (Hz)')
title('Change in governor speed regulation parameter (R)')
figure(6)
plot(time,delta_ptie,'y','LineWidth',1.85)
legend('zero','+%25','-%25','+%50','-%50','Location','South')
xlabel('time (sec)')
ylabel('\DeltaP_t_i_e (pu)')
title('Change in governor speed regulation parameter (R)')
