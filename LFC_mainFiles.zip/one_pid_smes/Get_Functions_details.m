% This function containts full information and implementations of the benchmark 
% functions in Table 1, Table 2, and other test functins from the literature 

% lb is the lower bound: lb=[lb_1,lb_2,...,lb_d]
% up is the uppper bound: ub=[ub_1,ub_2,...,ub_d]
% dim is the number of variables (dimension of the problem)

function [lb,ub,dim,fobj] = Get_Functions_details(F)

switch F
    case 'F1'
        fobj = @F1;
        lb=-100;
        ub=100;
        dim=10;
        
    case 'F2'
        fobj=@F2;
        lb=0.01;
        ub=10;
        dim=9;
end

end

% F1

function o = F1(x)
o=sum(x.^2);
end

function o = F2(x)
global p1 p2 p3 k1 k2 k3 k4 k_smes t_smes

 p1=x(1);
 p2=x(2);
 p3=x(3);
 k1=x(4);
 k2=x(5);
 k3=x(6);
 k4=x(7);
 k_smes=x(8);
 t_smes=x(9);
 
sim('AGC_PID_two_area_smes_one_pid');
ZZ=abs(delta_f1)+abs(delta_f2)+abs(delta_ptie);
           
o=trapz(time,time.*ZZ);
end
