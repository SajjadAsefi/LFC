clc
clear all
close all

%% delta_f1
figure(1)
A=xlsread('parameters','G4:G14');
p1=A(1);
p2=A(2);
p3=A(3);
k1=A(4);
k2=A(5);
k3=A(6);
k4=A(7);
k_smes=A(8);
t_smes=A(9);
sim('AGC_PID_two_area_smes_one_pid_1.slx')
plot(time,delta_f1,'r','LineWidth',1.85)
hold on
xlabel('time (sec)')
ylabel('\Deltaf_1 (HZ)')
A=xlsread('parameters','E4:E18');
p1=A(1);
p2=A(2);
p3=A(3);
p4=A(4);
p5=A(5);
p6=A(6);
p7=A(7);
p8=A(8);
p9=A(9);
k1=A(10);
k2=A(11);
k3=A(12);
k4=A(13);
k_smes=A(14);
t_smes=A(15);
sim('AGC_PID_two_area_smes_1.slx')
plot(time,delta_f1,':','LineWidth',1.85)
legend('SMES with one PID','SMES with three PID','Location','SouthEast')
%% delta_f2
figure(2)
A=xlsread('parameters','G4:G14');
p1=A(1);
p2=A(2);
p3=A(3);
k1=A(4);
k2=A(5);
k3=A(6);
k4=A(7);
k_smes=A(8);
t_smes=A(9);
sim('AGC_PID_two_area_smes_one_pid_1.slx')
plot(time,delta_f2,'r','LineWidth',1.85)
hold on
xlabel('time (sec)')
ylabel('\Deltaf_2 (HZ)')
A=xlsread('parameters','E4:E18');
p1=A(1);
p2=A(2);
p3=A(3);
p4=A(4);
p5=A(5);
p6=A(6);
p7=A(7);
p8=A(8);
p9=A(9);
k1=A(10);
k2=A(11);
k3=A(12);
k4=A(13);
k_smes=A(14);
t_smes=A(15);
sim('AGC_PID_two_area_smes_1.slx')
plot(time,delta_f2,':','LineWidth',1.85)
legend('SMES with one PID','SMES with three PID','Location','SouthEast')
%% delta_ptie
figure(3)
A=xlsread('parameters','G4:G14');
p1=A(1);
p2=A(2);
p3=A(3);
k1=A(4);
k2=A(5);
k3=A(6);
k4=A(7);
k_smes=A(8);
t_smes=A(9);
sim('AGC_PID_two_area_smes_one_pid_1.slx')
plot(time,delta_ptie,'r','LineWidth',1.85)
hold on
xlabel('time (sec)')
ylabel('\DeltaP_t_i_e (pu)')
A=xlsread('parameters','E4:E18');
p1=A(1);
p2=A(2);
p3=A(3);
p4=A(4);
p5=A(5);
p6=A(6);
p7=A(7);
p8=A(8);
p9=A(9);
k1=A(10);
k2=A(11);
k3=A(12);
k4=A(13);
k_smes=A(14);
t_smes=A(15);
sim('AGC_PID_two_area_smes_1.slx')
plot(time,delta_ptie,':','LineWidth',1.85)
legend('SMES with one PID','SMES with three PID','Location','SouthEast')